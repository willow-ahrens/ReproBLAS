var searchData=
[
  ['diwidth',['DIWIDTH',['../idxd_8h.html#a599505844cb962d59e19656425c138e4',1,'idxd.h']]]
];
