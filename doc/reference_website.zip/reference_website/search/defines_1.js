var searchData=
[
  ['idxd_5fdicapacity',['idxd_DICAPACITY',['../idxd_8h.html#ab46dd78091caab74e25a9faa5199ed94',1,'idxd.h']]],
  ['idxd_5fdiendurance',['idxd_DIENDURANCE',['../idxd_8h.html#a2af954e9bac7c6a6aa4cd03449a7a22a',1,'idxd.h']]],
  ['idxd_5fdimaxfold',['idxd_DIMAXFOLD',['../idxd_8h.html#a7782edd0de1008d39f4f9d92816d09b3',1,'idxd.h']]],
  ['idxd_5fdimaxindex',['idxd_DIMAXINDEX',['../idxd_8h.html#a6724376962c17b824208b67d49089b05',1,'idxd.h']]],
  ['idxd_5fdmcompression',['idxd_DMCOMPRESSION',['../idxd_8h.html#a09ea8fbab57dae125c1f34eb35eee883',1,'idxd.h']]],
  ['idxd_5fdmexpansion',['idxd_DMEXPANSION',['../idxd_8h.html#a040339c081037d4757f512efd6ccb474',1,'idxd.h']]],
  ['idxd_5fsicapacity',['idxd_SICAPACITY',['../idxd_8h.html#a40ee6f4d2be2e37ab6bc76f17f582edf',1,'idxd.h']]],
  ['idxd_5fsiendurance',['idxd_SIENDURANCE',['../idxd_8h.html#a14129e0c6c6bca93e0ed7c521897f794',1,'idxd.h']]],
  ['idxd_5fsimaxfold',['idxd_SIMAXFOLD',['../idxd_8h.html#a2d8f62d952980e30d30a562688e72e8a',1,'idxd.h']]],
  ['idxd_5fsimaxindex',['idxd_SIMAXINDEX',['../idxd_8h.html#a3a44f683987188a73a727c6505ee7905',1,'idxd.h']]],
  ['idxd_5fsmcompression',['idxd_SMCOMPRESSION',['../idxd_8h.html#af198fd6d0c0c989ab612587d3ab0c20a',1,'idxd.h']]],
  ['idxd_5fsmexpansion',['idxd_SMEXPANSION',['../idxd_8h.html#adef77262410180d40f358dee51da820b',1,'idxd.h']]]
];
