var searchData=
[
  ['idxd_2eh',['idxd.h',['../idxd_8h.html',1,'']]],
  ['idxdblas_2eh',['idxdBLAS.h',['../idxd_b_l_a_s_8h.html',1,'']]]
];
