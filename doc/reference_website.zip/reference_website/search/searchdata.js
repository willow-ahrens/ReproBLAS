var indexSectionsWithContent =
{
  0: "dfis",
  1: "i",
  2: "i",
  3: "df",
  4: "dis"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "typedefs",
  4: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Typedefs",
  4: "Macros"
};

