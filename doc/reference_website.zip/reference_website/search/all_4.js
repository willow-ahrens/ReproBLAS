var searchData=
[
  ['siwidth',['SIWIDTH',['../idxd_8h.html#ab413e780857154cb96be6cef85757a6b',1,'idxd.h']]]
];
